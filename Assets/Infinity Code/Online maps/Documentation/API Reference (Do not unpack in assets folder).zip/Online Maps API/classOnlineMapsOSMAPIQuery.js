var classOnlineMapsOSMAPIQuery =
[
    [ "OnlineMapsOSMAPIQuery", "classOnlineMapsOSMAPIQuery.html#a3e3d7687c8051980ed7e218846b40c67", null ],
    [ "type", "classOnlineMapsOSMAPIQuery.html#aa2302eb8f93d86c6b9d597d2c67f7988", null ]
];