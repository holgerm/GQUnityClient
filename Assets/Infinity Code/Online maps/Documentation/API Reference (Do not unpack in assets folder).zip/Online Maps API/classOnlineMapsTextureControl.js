var classOnlineMapsTextureControl =
[
    [ "GetCoords", "classOnlineMapsTextureControl.html#a8b35a08644fc8eeea19485bcff09f32f", null ],
    [ "SetTexture", "classOnlineMapsTextureControl.html#a17fabdfd94154b0c7b7b636beaffbfaa", null ]
];