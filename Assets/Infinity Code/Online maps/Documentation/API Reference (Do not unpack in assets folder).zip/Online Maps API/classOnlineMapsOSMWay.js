var classOnlineMapsOSMWay =
[
    [ "OnlineMapsOSMWay", "classOnlineMapsOSMWay.html#af8d4b70698d52ca9efde14b37770ffe6", null ],
    [ "nodeRefs", "classOnlineMapsOSMWay.html#a39bb2c0cbc960cbb755fa18a71ce8131", null ]
];