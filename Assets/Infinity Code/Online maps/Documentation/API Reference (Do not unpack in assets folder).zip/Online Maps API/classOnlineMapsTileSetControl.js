var classOnlineMapsTileSetControl =
[
    [ "AfterUpdate", "classOnlineMapsTileSetControl.html#a5ed9d0d869c8b33592d1027e43683dd1", null ],
    [ "GetBestElevationYScale", "classOnlineMapsTileSetControl.html#af0666b516bd8c1db18a5f8b29ff2c79c", null ],
    [ "GetCoords", "classOnlineMapsTileSetControl.html#a6e3cd935b37d0df85976daf1780a3414", null ],
    [ "GetElevationValue", "classOnlineMapsTileSetControl.html#ade9262f27307f9c6417bcadca7e4a852", null ],
    [ "HitTest", "classOnlineMapsTileSetControl.html#af1dcfd2debdd2933346c38dd151f14db", null ],
    [ "OnAwakeBefore", "classOnlineMapsTileSetControl.html#af5a559e301568d9ef6d74fa8a34243e1", null ],
    [ "SetElevationData", "classOnlineMapsTileSetControl.html#aa6ff42a2bc6a86560cd015c85565aad9", null ],
    [ "UpdateControl", "classOnlineMapsTileSetControl.html#ad13b514cae37d0e2fdf237b686f247c8", null ],
    [ "bingAPI", "classOnlineMapsTileSetControl.html#a5024a0827e8e792e24bb6b2ea3364b44", null ],
    [ "drawingsGameObject", "classOnlineMapsTileSetControl.html#a3cd355b7100cbb0e4f09aeb749bcfb05", null ],
    [ "OnChangeMaterialTexture", "classOnlineMapsTileSetControl.html#a042e89034b65cbb05a3cd54d251a26c5", null ],
    [ "OnGetElevation", "classOnlineMapsTileSetControl.html#a08895931d209cf0f32cf84e223ef5fb3", null ],
    [ "tileMaterial", "classOnlineMapsTileSetControl.html#a0f49b840e8637b6acea5cc0db88ec861", null ],
    [ "useElevation", "classOnlineMapsTileSetControl.html#a434951f9f254b4dbd71f754c1fdb9850", null ]
];